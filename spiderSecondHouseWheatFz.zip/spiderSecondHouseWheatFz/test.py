# -*- coding: UTF-8 -*-
import re
import shlex

_param = '高楼层/7层|2.5室2厅1卫1阳|南北'+str(1)
#_param:'''+str(1)+'''

print(_param)